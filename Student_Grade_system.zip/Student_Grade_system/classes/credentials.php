<?php
// local db connection
$host = "localhost";
$charset = "utf8";
$dbusr = "root";
$dbpwd = "";
$dbname = "grading_system";
global $config;
?>
